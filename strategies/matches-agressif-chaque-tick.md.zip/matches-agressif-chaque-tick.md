# Strategie Matches agressive chaque tick

Profil importable pour le bot Matches. Cette strategie n'est pas stricte: elle cherche a prendre un contrat des qu'un tick permet de classer un digit dynamique.

Attention: ce profil augmente fortement le nombre de trades et peut augmenter les pertes. Il desactive le filtre payout/Edge pour executer plus vite.

```json
{
  "strategy": "advanced_matches",
  "version": 1,
  "name": "Matches agressif chaque tick",
  "contractType": "DIGITMATCH",
  "barrierMode": "dynamic",
  "fixedDigit": null,
  "contractsPerSignal": 1,
  "stake": null,
  "bypassPayoutFilter": true,
  "rules": {
    "minimumTicks": 1,
    "minimumProbability": 0.1,
    "minimumAgreementScore": 1,
    "minimumDominanceGap": 0,
    "minimumMediumProbability": 0,
    "minimumShortProbability": 0,
    "minimumEdge": -1,
    "requireConditionalEvidence": false
  },
  "risk": {
    "digitBlockAfterLosses": 10,
    "digitBlockTicksMultiplier": 1,
    "digitBlockMaxTicks": 1
  }
}
```

## Comportement

- Contrat force: `DIGITMATCH`.
- Digit: dynamique.
- Echantillon minimum: 1 tick.
- Filtre Edge/payout: desactive.
- Confirmation contexte/transition: desactivee.
- Blocage digit perdant: pratiquement desactive, car il faut 10 pertes sur le meme digit.

## Utilisation

1. Ouvrir `Deriv Bot`.
2. Choisir `Full automatique`.
3. Selectionner `Matches / Differs`, puis `Matches`.
4. Cliquer sur `Importer .md`.
5. Importer ce fichier.

Si le compte Deriv Options est connecte, le bot passe en mode auto et commence a scanner/executer avec ce profil.
